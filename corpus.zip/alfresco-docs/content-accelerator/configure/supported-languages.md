---
title: Supported languages
---

* DE - German
* EN - English
* ES - Spanish
* FR - French
* IT - Italian
* JA - Japanese - `This Language pack is presently experimental and may not always produce the desired results.`
* NL - Dutch
