---
title: Supported platforms
---

The following are the supported platforms for the Alfresco Content Accelerator 3.5:

## Alfresco Content Services

| Version | Notes |
| ------- | ----- |
| Content Services 7.4 | Requires Content Accelerator 3.5.1 or later |
| Content Services 7.3 | |
| Content Services 7.2 | |
| Content Services 7.1 | |
| Content Services 7.0 | |
