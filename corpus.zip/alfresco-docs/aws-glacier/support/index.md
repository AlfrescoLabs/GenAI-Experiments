---
title: Supported platforms
---

The following are the supported platforms for the Content Connector for AWS Glacier 2.2:

| Version | Notes |
| ------- | ----- |
| Alfresco Content Services 7.1 | |
| Alfresco Governance Services 7.1 | |
| Alfresco Content Connector for AWS S3 4.1 | |
