---
title: Supported platforms
---

The following are the supported platforms for the Content Connector for AWS S3 version 5.1:

| Version | Notes |
| ------- | ----- |
| Alfresco Content Services 7.3.x |  |
| Alfresco Content Services 7.2.x |  |
