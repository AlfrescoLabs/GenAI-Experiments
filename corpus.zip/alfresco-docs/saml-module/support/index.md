---
title: Supported platforms
---

The following are the supported platforms for SAML Module for Alfresco Content Services:

## Alfresco Content Services

| Version | Notes |
| ------- | ----- |
| Content Services 7.2 | |
| Content Services 7.1 | |
| Content Services 7.0 | |
| Content Services 6.2 | |

## Application servers

| Version | Notes |
| ------- | ----- |
| Tomcat 8.5.43 | |

## Microsoft Office

| Version | Notes |
| ------- | ----- |
| Microsoft Office 2013 | |
| Microsoft Office 2016 | |
