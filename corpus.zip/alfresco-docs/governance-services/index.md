---
title: Alfresco Governance Services
---

Governance Services combines Records Management with Security Controls and Classification.

Governance Services is fully compliant with a baseline of DoD 5015.02. With Governance Services you can fully automate 
the record lifecycle from capture through retention to final destruction. Users can create records direct from any 
Alfresco Share site. On top of this security controls and classification give you complete control over who can see 
which records and when.
