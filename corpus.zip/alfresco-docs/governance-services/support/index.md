---
title: Supported platforms
---

The following are the supported platforms for the Alfresco Governance Services version 7.4.x:

| Version | Notes |
| ------- | ----- |
| Alfresco Content Services 7.4.x |
