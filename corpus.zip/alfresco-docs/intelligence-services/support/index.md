---
title: Supported platforms
---

The following are the supported platforms for Alfresco Intelligence Services 1.5:

| Version | Notes |
| ------- | ----- |
| Content Services 7.4.x | |
| Transform Service 1.5.x | |
| Digital Workspace 2.8 | |
