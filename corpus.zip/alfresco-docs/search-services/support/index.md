---
title: Supported platforms
---

The following are the supported platforms for Search Services:

## Alfresco Content Services

| Version | Notes |
| ------- | ----- |
| Content Services 7.3.x | |
| Content Services 7.2.x | |
| Content Services 7.1.x | |
| Content Services 7.0.x | |
| Content Services 6.2.2 | |
| Content Services 6.2.1 | |
