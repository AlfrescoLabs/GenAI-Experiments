---
title: Supported platforms
---

The following are the supported platforms for Alfresco Content Connector for SAP applications:

| Version | Notes |
| ------- | ----- |
| Content Services 7.3.x | |
| Content Services 7.2.x | |
| Content Services 7.1.x | |
| Content Services 7.0.x | |
| Content Services 6.2.x | |
