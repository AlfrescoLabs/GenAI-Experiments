---
title: Supported platforms
---

The following are the supported platforms for the Content Connector for Salesforce 2.4:

| Version | Notes |
| ------- | ----- |
| Content Services 7.4.x | |
| Identity Service 1.8 | If using Single Sign On (SSO) |

> **Note:** Support for Salesforce Community is only available when using Alfresco Cloud (PaaS).
