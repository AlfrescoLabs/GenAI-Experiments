---
title: Supported platforms
---

The following are the supported platforms for Alfresco Office Services:

## Alfresco Content Services

| Version | Notes |
| ------- | ----- |
| Content Services 7.4 | |
| Community Edition 7.4 | |
