---
title: Supported platforms
---

The following are the supported platforms for Document Transformation Engine 2.3.1:

| Version | Notes |  
| ------- | ----- |
| Content Services 7.1.x | *Optional.* Use with DTE T-Engine v1.2.0 |
| Content Services 7.0.x | *Optional.* Use with DTE T-Engine v1.2.0 |
| | |
| **Java** | |
| Oracle JDK 11 | |
| | |
| **Microsoft Windows Server** | |  
| Microsoft Windows Server 2019 | |
| Microsoft Windows Server 2016 | |
| Microsoft Windows Server 2012 | |
| | |
| **Microsoft Office** | |
| Microsoft Office 2019 32/64 bit | |
| Microsoft Office 2016 32/64 bit | |
