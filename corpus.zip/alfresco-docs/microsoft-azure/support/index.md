---
title: Supported platforms
---

The following are the supported platforms for Alfresco Content Connector for Azure 3.2:

## Alfresco Content Services

| Version | Notes |
| ------- | ----- |
| Content Services 7.4.x | |
| Content Services 7.3.x | |
| Content Services 7.2.x | |
