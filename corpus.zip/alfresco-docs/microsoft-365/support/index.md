---
title: Supported platforms
---

The following are the supported platforms for the Alfresco Collaboration Connector for Microsoft 365 version 2.0:

| Version | Notes |
| ------- | ----- |
| Alfresco Content Services 7.4.x | |
| Alfresco Digital Workspace 4.0.x | |
