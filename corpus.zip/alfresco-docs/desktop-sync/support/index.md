---
title: Supported platforms
---

The following are the supported platforms for Desktop Sync 1.16:

| Version | Notes |
| ------- | ----- |
| Content Services 7.4.x | |
| Content Services 7.3.x | |
| Content Services 7.2.x | |

**Note:** This version of Desktop Sync doesn't support Smart Folders.
