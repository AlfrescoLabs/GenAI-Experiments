---
title: Supported platforms
---

The following are the supported platforms for Google Docs Integration:

## Alfresco Content Services

| Version | Notes |
| ------- | ----- |
| Content Services 7.4 | |
| Content Services 7.3 | |
| Content Services 7.2 | |
| Community Edition 7.4 | |
