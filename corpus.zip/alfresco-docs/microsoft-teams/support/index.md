---
title: Supported platforms
---

The following are the supported platforms for the Alfresco Collaboration Connector for Teams 2.0:

|Version|Notes|
|-------|-----|
|Alfresco Content Services 7.4.x|Exposed via HTTPS|
|Alfresco Identity Service 1.8.x|Exposed via HTTPS|
|Alfresco Digital Workspace 4.0.x|Exposed via HTTPS|
