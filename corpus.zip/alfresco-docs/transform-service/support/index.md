---
title: Supported Platforms
---

The following are the supported platforms and software requirements for Alfresco Transform Service 3.0:

|Version|Notes|
|-------|-----|
|Content Services 7.4.x||
