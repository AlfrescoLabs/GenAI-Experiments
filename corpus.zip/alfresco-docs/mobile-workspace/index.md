---
title: Alfresco Mobile Workspace
---

Alfresco Mobile Workspace enables you to have a seamless experience across multiple platforms because it gives you the ability to work away from your workstation without compromising the way you access content. You can view your libraries, recent and shared files, and manage your favorites from your mobile device. You can view all major document types including Microsoft Word, Excel, and PowerPoint. You can also view images, including but not limited to `JPEG` and `PNG`. You can use the Mobile Workspace to manage and view content while offline and it has a dark mode to support your well-being.
