---
title: Supported platforms
---

The following are the supported platforms for Alfresco Media Management:

## Alfresco Content Services

| Version | Notes |
| ------- | ----- |
| Content Services 6.2 | |
