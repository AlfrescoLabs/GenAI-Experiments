---
title: Supported platforms
---

The following are the supported platforms for the Alfresco Enterprise Viewer 3.5:

| Version | Notes |
| ------- | ----- |
| Content Services 7.4 | Requires Enterprise Viewer 3.5.1 and later |
| Content Services 7.3.x | |
| Content Services 7.2.x | |
| Content Services 7.1.x | |
| Content Services 7.0.x | |
