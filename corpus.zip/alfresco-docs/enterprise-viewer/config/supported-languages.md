---
title: Supported languages
---

* DE - German
* EN - English
* ES - Spanish
* FR - French
* IT - Italian
* JA - Japanese
* NL - Dutch
